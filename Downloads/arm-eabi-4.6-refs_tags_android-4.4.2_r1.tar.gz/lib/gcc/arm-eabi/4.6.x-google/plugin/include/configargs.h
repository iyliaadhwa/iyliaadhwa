/* Generated automatically. */
static const char configuration_arguments[] = "/tmp/android-15472/src/build/../gcc/gcc-4.6/configure --prefix=/usr/local --target=arm-eabi --host=x86_64-linux-gnu --build=x86_64-linux-gnu --with-gnu-as --with-gnu-ld --enable-languages=c,c++ --with-gmp=/tmp/android-15472/obj/temp-install --with-mpfr=/tmp/android-15472/obj/temp-install --with-mpc=/tmp/android-15472/obj/temp-install --without-ppl --without-cloog --disable-libssp --enable-threads --disable-nls --disable-libmudflap --disable-libgomp --disable-libstdc__-v3 --disable-sjlj-exceptions --disable-shared --disable-tls --disable-libitm --with-float=soft --with-fpu=vfp --with-arch=armv5te --enable-target-optspace --with-abi=aapcs --with-gcc-version=4.6 --with-binutils-version=2.21 --with-gmp-version=4.2.4 --with-mpfr-version=2.4.1 --with-gdb-version=7.3.x --with-arch=armv5te --with-sysroot=/tmp/android-15472/install/sysroot --with-prefix=/tmp/android-15472/install --with-gold-version=2.21 --enable-gold --disable-gold --disable-multilib --program-transform-name='s&^&arm-eabi-&'";
static const char thread_model[] = "single";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { "abi", "aapcs" }, { "arch", "armv5te" }, { "float", "soft" }, { "fpu", "vfp" } };
